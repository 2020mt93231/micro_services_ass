﻿using BitsPilani.UserRegistration.BL.UserRegistration.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace BitsPilani.UserRegistration.BL.UserRegistration.UserRegistrationVM
{
    public class UserVM
    {
        public IList<UserRegistrationDTO> UserList { get; set; }
    }
}
