﻿using AutoMapper;
using BitsPilani.UserRegistration.BL.UserRegistration.DTO;
using BitsPilani.UserRegistration.BL.UserRegistration.UserRegistrationVM;
using BitsPilani.UserRegistration.Common.BaseClass;
using BitsPilani.UserRegistration.Common.Interfaces;
using BitsPilani.UserRegistration.Common.UnitOfWork;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BitsPilani.UserRegistration.BL.UserRegistration.Queries
{
    public class GetSingleUserQuery : IRequest<UserVM>
    {
        public int UserID { get; set; }
        public class GetSingleUserHandler : BaseClass, IRequestHandler<GetSingleUserQuery, UserVM>
        {
            public GetSingleUserHandler(IConfigConstants constant, IMapper mapper, IUnitOfWork unitOfWork)
                : base(constant, unitOfWork, mapper)
            {
            }

            public async Task<UserVM> Handle(GetSingleUserQuery request, CancellationToken cancellationToken)
            {
                var res = this.Mapper.Map(this.UnitOfWork.Users.GetRegisteredUser(request.UserID).Result, new UserRegistrationDTO());
                return await Task.FromResult(new UserVM() { UserList = new List<UserRegistrationDTO> { res } });
            }
        }
    }
}
