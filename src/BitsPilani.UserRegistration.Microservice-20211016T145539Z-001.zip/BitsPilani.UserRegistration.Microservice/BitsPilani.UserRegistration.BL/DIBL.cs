﻿using BitsPilani.UserRegistration.BL.UserRegistration.Commands;
using BitsPilani.UserRegistration.BL.UserRegistration.Queries;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace BitsPilani.UserRegistration.BL
{
    public static class DIBL
    {
        public static IServiceCollection AddBLRegistration(this IServiceCollection services)
        {
            services.AddMediatR(typeof(AddUserCommand).GetTypeInfo().Assembly);
            services.AddMediatR(typeof(DeleteUserCommand).GetTypeInfo().Assembly);
            services.AddMediatR(typeof(UpdateUserCommand).GetTypeInfo().Assembly);
            services.AddMediatR(typeof(GetAllUserQuery).GetTypeInfo().Assembly);
            services.AddMediatR(typeof(GetSingleUserQuery).GetTypeInfo().Assembly);
            return services;
        }
    }
}
