﻿using BitsPilani.Course.Common.Repositories;
using System;
using System.Collections.Generic;
using System.Text;

namespace BitsPilani.Course.Common.UnitOfWork
{
    public interface IUnitOfWork
    {
        ICourseRepository Users { get; }
        void StartTransaction();
        void Commit();
    }
}
