﻿using AutoMapper;
using BitsPilani.Course.Common.Interfaces;
using BitsPilani.Course.Common.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Text;

namespace BitsPilani.Course.Common.BaseClass
{
    public class CourseBase
    {
        public IUnitOfWork UnitOfWork { get; set; }
        public IConfigConstants ConfigConstants { get; set; }
        public IMapper Mapper { get; set; }

        public CourseBase(IConfigConstants configConstants, IUnitOfWork unitOfWork, IMapper mapper)
        {
            ConfigConstants = configConstants;
            UnitOfWork = unitOfWork;
            Mapper = mapper;
        }
    }
}
