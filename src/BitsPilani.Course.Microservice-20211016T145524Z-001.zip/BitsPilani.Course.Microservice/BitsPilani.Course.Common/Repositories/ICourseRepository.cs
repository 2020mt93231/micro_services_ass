﻿using BitsPilani.Course.Common.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
namespace BitsPilani.Course.Common.Repositories
{
    public interface ICourseRepository
    {
        Task<int> AddCourse(Entities.Course course);
        Task<bool> UpdateCourse(Entities.Course course);
        Task<bool> DeleteCourse(int courseId);
        Task<IEnumerable<Entities.Course>> GetAllCourses();
        Task<Entities.Course> GetCourse(long courseId);
        Task<bool> DeleteAllCourses();
    }
}
