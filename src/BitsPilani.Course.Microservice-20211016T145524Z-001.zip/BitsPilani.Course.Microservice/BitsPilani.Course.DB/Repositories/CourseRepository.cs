﻿using BitsPilani.Course.Common.Repositories;
using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using CourseDTO = BitsPilani.Course.Common.Entities.Course;
namespace BitsPilani.Course.DB.Repositories
{
    public class CourseRepository : Repository, ICourseRepository
    {
        public CourseRepository(IDbConnection dbConnection, IDbTransaction dbtransaction)
           : base(dbConnection, dbtransaction)
        {
        }
        public Task<int> AddCourse(CourseDTO course)
        {
            course.DateAdded = DateTime.Now;
            course.DateUpdated = null;
            return DbConnection.InsertAsync(course, DbTransaction);
        }

        public Task<bool> DeleteCourse(int courseId)
        {
            return DbConnection.DeleteAsync(new CourseDTO { CourseID = courseId }, DbTransaction);
        }


        public Task<IEnumerable<CourseDTO>> GetAllCourses()
        {
            return DbConnection.GetAllAsync<CourseDTO>();
        }

        public Task<CourseDTO> GetCourse(long courseId)
        {
            return DbConnection.GetAsync<CourseDTO>(courseId);
        }

        public Task<bool> UpdateCourse(CourseDTO Course)
        {
            Course.DateUpdated = DateTime.Now;
            return DbConnection.UpdateAsync(Course, DbTransaction);
        }
        public Task<bool> DeleteAllCourses()
        {
            return DbConnection.DeleteAllAsync<CourseDTO>();
        }
    }
}
