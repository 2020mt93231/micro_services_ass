﻿using BitsPilani.Course.Common.Repositories;
using BitsPilani.Course.Common.UnitOfWork;
using BitsPilani.Course.DB.Repositories;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace BitsPilani.Course.DB.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private IDbConnection dbConnection;
        private IDbTransaction transaction;
        public UnitOfWork(IDbConnection dbConnection)
        {
            this.dbConnection = dbConnection;
            this.ManageConnection();
        }
        public ICourseRepository Users => new CourseRepository(this.dbConnection, this.transaction);

        public void Commit()
        {
            try
            {
                this.transaction.Commit();
            }
            catch
            {
                this.transaction.Rollback();
            }
        }

        public void StartTransaction()
        {

            if (this.transaction == null)
            {
                this.transaction = this.dbConnection.BeginTransaction();
            }
        }

        private void ManageConnection()
        {
            if (this.dbConnection.State == ConnectionState.Closed)
            {
                this.dbConnection.Open();
            }
        }
    }
}
