﻿using BitsPilani.Course.Common.Constants;
using BitsPilani.Course.Common.Interfaces;
using BitsPilani.Course.Common.UnitOfWork;
using Microsoft.Extensions.DependencyInjection;
using System.Data;
using System.Data.SqlClient;

namespace BitsPilani.Course.DB
{
    public static class DBDependencyInjection
    {
        public static IServiceCollection AddDB(this IServiceCollection services)
        {
            services.AddSingleton<IConfigConstants, ConfigConstants>();
            services.AddSingleton<IDbConnection>(conn => new SqlConnection(conn.GetService<IConfigConstants>().CourseConnection));
            services.AddTransient<IUnitOfWork>(uof => new UnitOfWork.UnitOfWork(uof.GetService<IDbConnection>()));
            return services;
        }
    }
}
