﻿using BitsPilani.Course.BL.Course.Commands;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace BitsPilani.Course.BL
{
    public static class BLDependencyInjection
    {
        public static IServiceCollection AddBL(this IServiceCollection services)
        {
            services.AddMediatR(typeof(CreateCourseCommand).GetTypeInfo().Assembly);
            services.AddMediatR(typeof(DeleteCourseCommand).GetTypeInfo().Assembly);
            services.AddMediatR(typeof(ModifyCourseCommand).GetTypeInfo().Assembly);
            return services;
        }
    }
}
