﻿using BitsPilani.Course.BL.Course.DTO;
using System;
using System.Collections.Generic;
using System.Text;
namespace BitsPilani.Course.BL.ViewModel
{
    public class BitCourseVM
    {
        public IList<CourseDTO> CourseList { get; set; }
    }
}
