﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using BitsPilani.Course.Common.Mappings;

namespace BitsPilani.Course.BL.Course.DTO
{
    public class CourseDTO : IMapFrom<Common.Entities.Course>
    {
        public int CourseID { get; set; }
        public string CourseName { get; set; }
        public string CourseShortName { get; set; }
        public double CreditHour { get; set; }
        public double Price { get; set; }
        public DateTime DateAdded { get; set; }
        public DateTime? DateUpdated { get; set; }
        public void Mapping(Profile profile)
        {
            profile.CreateMap<CourseDTO, Common.Entities.Course>();
            profile.CreateMap<Common.Entities.Course, CourseDTO>();
        }
    }
}
