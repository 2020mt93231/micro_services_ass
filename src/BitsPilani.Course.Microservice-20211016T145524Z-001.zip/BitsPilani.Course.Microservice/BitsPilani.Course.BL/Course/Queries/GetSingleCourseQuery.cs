﻿using BitsPilani.Course.BL.ViewModel;
using BitsPilani.Course.Common.BaseClass;
using BitsPilani.Course.Common.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace BitsPilani.Course.BL.Course.Queries
{
    public class GetSingleCourseQuery : IRequest<BitCourseVM>
    {
        public int CourseID { get; set; }
      
    }
}
