﻿using AutoMapper;
using BitsPilani.Course.Common.BaseClass;
using BitsPilani.Course.Common.Interfaces;
using BitsPilani.Course.Common.UnitOfWork;
using MediatR;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using BitsPilani.Course.BL.ViewModel;
using BitsPilani.Course.BL.Course.DTO;

namespace BitsPilani.Course.BL.Course.Queries
{
    public class GetAllCourseQuery : IRequest<BitCourseVM>
    {
        public class GetAllUserHandler : CourseBase, IRequestHandler<GetAllCourseQuery, BitCourseVM>
        {
            public GetAllUserHandler(IConfigConstants constant, IMapper mapper, IUnitOfWork unitOfWork)
                : base(constant, unitOfWork, mapper)
            {
            }

            public async Task<BitCourseVM> Handle(GetAllCourseQuery request, CancellationToken cancellationToken)
            {
                var res = Mapper.Map(UnitOfWork.Users.GetAllCourses().Result, new List<CourseDTO>());
                return await Task.FromResult(new BitCourseVM() { CourseList = res });
            }
        }
    }
}
