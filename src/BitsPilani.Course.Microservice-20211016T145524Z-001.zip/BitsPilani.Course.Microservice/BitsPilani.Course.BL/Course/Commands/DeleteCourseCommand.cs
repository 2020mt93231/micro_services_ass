﻿using AutoMapper;
using BitsPilani.Course.Common.BaseClass;
using BitsPilani.Course.Common.Interfaces;
using BitsPilani.Course.Common.UnitOfWork;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BitsPilani.Course.BL.Course.Commands
{
    public class DeleteCourseCommand : IRequest<bool>
    {
        public int CourseID { get; set; }
        public class DeleteUserHandler : CourseBase, IRequestHandler<DeleteCourseCommand, bool>
        {
            public DeleteUserHandler(IConfigConstants constant, IMapper mapper, IUnitOfWork unitOfWork)
                : base(constant, unitOfWork, mapper)
            {
            }

            public async Task<bool> Handle(DeleteCourseCommand request, CancellationToken cancellationToken)
            {
                this.UnitOfWork.StartTransaction();
                var res = UnitOfWork.Users.DeleteCourse(request.CourseID).Result;
                this.UnitOfWork.Commit();
                return await Task.Run(() => res, cancellationToken);
            }
        }
    }
}
