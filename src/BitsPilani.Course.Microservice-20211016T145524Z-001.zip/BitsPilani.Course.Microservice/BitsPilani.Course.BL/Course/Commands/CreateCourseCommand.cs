﻿using AutoMapper;
using BitsPilani.Course.Common.BaseClass;
using BitsPilani.Course.Common.Interfaces;
using BitsPilani.Course.Common.UnitOfWork;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using BitsCourse = BitsPilani.Course.Common.Entities.Course;
namespace BitsPilani.Course.BL.Course.Commands
{
    public class CreateCourseCommand:IRequest<int>
    {
        public string CourseName { get; set; }
        public string CourseShortName { get; set; }
        public double CreditHour { get; set; }
        public double Price { get; set; }
        public class AddNewUserHandler : CourseBase, IRequestHandler<CreateCourseCommand, int>
        {
            public AddNewUserHandler(IConfigConstants constant, IMapper mapper, IUnitOfWork unitOfWork)
                : base(constant, unitOfWork, mapper)
            {
            }

            public async Task<int> Handle(CreateCourseCommand request, CancellationToken cancellationToken)
            {
                var user = new BitsCourse
                {
                    CourseName = request.CourseName,
                    CourseShortName = request.CourseShortName,
                    CreditHour = request.CreditHour,
                    Price = request.Price,
                };
                this.UnitOfWork.StartTransaction();
                var res = UnitOfWork.Users.AddCourse(user).Result;
                this.UnitOfWork.Commit();
                return await Task.Run(() => res, cancellationToken);
            }

        }
    }
}
